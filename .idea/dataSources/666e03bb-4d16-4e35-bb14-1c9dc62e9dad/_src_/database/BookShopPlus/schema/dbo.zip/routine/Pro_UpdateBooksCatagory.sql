CREATE PROCEDURE [dbo].[Pro_UpdateBooksCatagory]
	-- Add the parameters for the stored procedure here
@Id int,
@CatagoryId int 
AS
BEGIN		
	Update Books set CategoryID=@CatagoryId where Id = @Id
END
GO
