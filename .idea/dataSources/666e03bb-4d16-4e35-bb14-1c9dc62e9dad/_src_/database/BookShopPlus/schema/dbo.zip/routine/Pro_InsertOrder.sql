



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Pro_InsertOrder]
	-- Add the parameters for the stored procedure here
	@OrderDate datetime,
	@UserId int,
	@TotalPrice decimal
AS
BEGIN  
      
	INSERT Orders (OrderDate, UserId, TotalPrice) VALUES (@OrderDate, @UserId, @TotalPrice)
    select max(id) from Orders
END


GO
