/*查询书籍 Created in 20090902*/
CREATE PROC sp_QueryBooks
@QueryCategory NVARCHAR(10),--查询类型
@KeyWord NVARCHAR(50)  --查询关键字
AS
IF(@QueryCategory='书名')
SELECT * FROM Books WHERE Title LIKE '%'+@KeyWord+'%'
ELSE IF(@QueryCategory='内容简介')
SELECT * FROM Books WHERE ContentDescription LIKE '%'+@KeyWord+'%'
ELSE IF(@QueryCategory='作者')
SELECT * FROM Books WHERE Author LIKE '%'+@KeyWord+'%'
ELSE IF(@QueryCategory='出版社')
SELECT Books.* FROM Books INNER JOIN Publishers
ON Books.PublisherId=Publishers.Id
WHERE Publishers.Name LIKE  '%'+@KeyWord+'%'


GO
